package carreiras.com.github.listadecompras

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import carreiras.com.github.kotlin_android_lista_de_compras.R


class EventAdapter(
    private val events: List<Event>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvLocal: TextView = itemView.findViewById(R.id.tvLocal)
        val tvTipo: TextView = itemView.findViewById(R.id.tvTipo)
        val tvGrau: TextView = itemView.findViewById(R.id.tvGrau)
        val tvData: TextView = itemView.findViewById(R.id.tvData)
        val tvPessoas: TextView = itemView.findViewById(R.id.tvPessoas)
        val btnExcluir: Button = itemView.findViewById(R.id.btnExcluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = events[position]
        holder.tvLocal.text = "Local: ${event.local}"
        holder.tvTipo.text = "Tipo: ${event.tipo}"
        holder.tvGrau.text = "Grau: ${event.grau}"
        holder.tvData.text = "Data: ${event.data}"
        holder.tvPessoas.text = "Pessoas Afetadas: ${event.pessoasAfetadas}"

        holder.btnExcluir.setOnClickListener {
            onDelete(position)
        }
    }

    override fun getItemCount(): Int = events.size
}
