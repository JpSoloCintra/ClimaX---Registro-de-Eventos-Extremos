package carreiras.com.github.listadecompras

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import carreiras.com.github.kotlin_android_lista_de_compras.R


class MainActivity : AppCompatActivity() {
    private lateinit var adapter: EventAdapter
    private val eventList = mutableListOf<Event>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etLocal = findViewById<EditText>(R.id.etLocal)
        val etTipo = findViewById<EditText>(R.id.etTipo)
        val etGrau = findViewById<EditText>(R.id.etGrau)
        val etData = findViewById<EditText>(R.id.etData)
        val etPessoas = findViewById<EditText>(R.id.etPessoas)
        val btnIncluir = findViewById<Button>(R.id.btnIncluir)
        val btnSobre = findViewById<Button>(R.id.btnSobre)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        adapter = EventAdapter(eventList) { position ->
            eventList.removeAt(position)
            adapter.notifyItemRemoved(position)
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        btnIncluir.setOnClickListener {
            val local = etLocal.text.toString().trim()
            val tipo = etTipo.text.toString().trim()
            val grau = etGrau.text.toString().trim()
            val data = etData.text.toString().trim()
            val pessoasStr = etPessoas.text.toString().trim()

            if (local.isEmpty() || tipo.isEmpty() || grau.isEmpty() || data.isEmpty() || pessoasStr.isEmpty()) {
                Toast.makeText(this, "Todos os campos são obrigatórios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val pessoas = pessoasStr.toIntOrNull()
            if (pessoas == null || pessoas <= 0) {
                Toast.makeText(this, "Número de pessoas deve ser maior que zero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val evento = Event(local, tipo, grau, data, pessoas)
            eventList.add(evento)
            adapter.notifyItemInserted(eventList.size - 1)

            etLocal.text.clear()
            etTipo.text.clear()
            etGrau.text.clear()
            etData.text.clear()
            etPessoas.text.clear()
        }

        btnSobre.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }
}
