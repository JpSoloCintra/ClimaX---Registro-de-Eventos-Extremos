package carreiras.com.github.listadecompras

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import carreiras.com.github.kotlin_android_lista_de_compras.R


class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}