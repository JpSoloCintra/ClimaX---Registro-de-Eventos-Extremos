package carreiras.com.github.listadecompras

data class Event(
    val local: String,
    val tipo: String,
    val grau: String,
    val data: String,
    val pessoasAfetadas: Int
)
